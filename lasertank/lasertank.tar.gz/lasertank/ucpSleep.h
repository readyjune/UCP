#ifndef UCPSLEEP_H
#define UCPSLEEP_H

void ucpSleep(float sec);

#endif
