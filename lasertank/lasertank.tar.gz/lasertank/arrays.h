void map(int Rows, int Columns, int Player_row, int Player_col, char* Player_direction, int Enemy_row, int Enemy_col, char* Enemy_direction);

