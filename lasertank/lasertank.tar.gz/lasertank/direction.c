void character_direction(char** array, int Player_row, int Player_col, char* Player_direction, int Enemy_col, int Enemy_row, char* Enemy_direction)
{
// Deciding Player Direction
	if (*Player_direction == 'n') 
	{
		array[Player_row][Player_col] = '^';
	}
	else if (*Player_direction == 's')
	{
		array[Player_row][Player_col] = 'v';
	}
	else if (*Player_direction == 'w')
	{
		array[Player_row][Player_col] = '<';
	}
	else if (*Player_direction == 'e')
	{
		array[Player_row][Player_col] = '>';
	}



// Deciding Enemy Direction
	if (*Enemy_direction == 'n') 
	{
		array[Enemy_row][Enemy_col] = '^';
	}
	else if (*Enemy_direction == 's')
	{
		array[Enemy_row][Enemy_col] = 'v';
	}
	else if (*Enemy_direction == 'w')
	{
		array[Enemy_row][Enemy_col] = '<';
	}
	else if (*Enemy_direction == 'e')
	{
		array[Enemy_row][Enemy_col] = '>';
	}
}

