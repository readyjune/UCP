#include <stdio.h>
#include <stdlib.h>
#include "arrays.h"
#include "string.h"
#include "laser.h"
#include "ucpSleep.h"
#include "direction.h"

//#pragma clang diagnostic push
//#pragma clang diagnostic ignored "-Wunused"

void map(int Rows, int Columns, int Player_row, int Player_col, char* Player_direction, int Enemy_row, int Enemy_col, char* Enemy_direction)
{

	system("clear");

	int i, j, k;
	char aux, temp;
//	char n, s, w, e;


	char** array = malloc(Rows*sizeof(char*));

//Making a square!!!
	for (i=0; i<Rows; i++)
	{
		array[i] = malloc(Columns*sizeof(char));
		for (j=0; j<Columns; j++)
		{
			if(i==0 || i==Rows-1 || j==0 || j==Columns-1)
			{
				array[i][j] = '*';
			}


			else
			{
				array[i][j] = ' ';
			}

		}
	}

//void character(int Player_row, int Player_col, char* Player_direction)

// Initialize Player and Enemy HP
	int player_hp = 100;
	int enemy_hp = 100;

// Deciding Player & Enemy Direction
character_direction(array, Player_row, Player_col, Player_direction, Enemy_col, Enemy_row, Enemy_direction);

// Printing Out Square ON Screen
	printf("Game's going on!!!!!!!!!!!!!\n");
	for (i=0; i<Rows; i++)
	{
		for(j=0; j<Columns; j++)
		{
			printf("%c", array[i][j]);
		}
		printf("\n");
	}



		
	char choice;

// While loop will continue until enemy is dead or player is dead
	while (enemy_hp > 0 && player_hp > 0)
	{
		printf("w to go/face up\n");
		printf("s to go/face down\n");
		printf("a to go/face left\n");
		printf("d to go/face right\n");
		printf("f to shooot laser\n");
		printf("action:			\n");
		scanf("%c", &choice);
//////////////////////////////////
//////    When player direction is North.
		if ((*Player_direction == 'n') && (enemy_hp > 0) && (player_hp > 0))
		{
			if (choice == 'w' && enemy_hp > 0 && player_hp > 0)
			{
				///When Player is just under the Enemy, and when player wants to move to North, it won't change anything.
				if ((Player_row-1)==Enemy_row && Player_col==Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					printf("can't change\n");
					system("clear");
					fflush(stdin);
				}
				//Same Columns with enemy but it will move until just under the enemy
				else if ((Player_row-1)!=Enemy_row && Player_col==Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					aux = array[Player_row-1][Player_col];
					array[Player_row-1][Player_col] = array[Player_row][Player_col];
					array[Player_row][Player_col] = aux;
					Player_row -= 1;
					*Player_direction = 'n';
					ucpSleep(0.25);
					system("clear");
					fflush(stdin);

				}
				//When Player meets the wall, it won't change anything.
				else if (Player_row-1 == 0)
				{
					printf("can't move\n");
					system("clear");
					fflush(stdin);
				}

				//When Player and Enemy is on different Column. (Assumption for making a enemy tank shoot the player tank)
				else if(Player_row - 1 > 0 && Player_col != Enemy_col && enemy_hp > 0 && player_hp > 0){
					//When Player moves only North, if enemy direction is North or South, it won't affect anyting. so player will just move to North)
					if (*Enemy_direction == 'n' || *Enemy_direction == 's')
					{
						aux = array[Player_row-1][Player_col];
						array[Player_row-1][Player_col] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_row -= 1;
						*Player_direction = 'n';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
					//But when enemy faces West or East and player moves but only if player tank is not just under the enemy, it will just move to North.
					else if ((*Enemy_direction == 'w' || *Enemy_direction == 'e') && Player_row-1 != Enemy_row && enemy_hp > 0 && player_hp > 0)
					{
						aux = array[Player_row-1][Player_col];
						array[Player_row-1][Player_col] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_row -= 1;
						*Player_direction = 'n';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
///////Enemy direction is West and tank is trying to pass that way. it will get shot.

					// When enemy faces West and Player-1 row is same with enemy row.
					else if ((*Enemy_direction == 'w') && Player_row-1 == Enemy_row && enemy_hp > 0 &&  player_hp > 0)
					{
						///// When enemy's facing a west side and player passes to enemy west side------YOU LOSE
						if (Player_col < Enemy_col)
						{

							aux = array[Player_row-1][Player_col];
							array[Player_row-1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row -= 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row][Enemy_col-1] = '-';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_col; k>Player_col+1; k--)
							{
								temp = array[Enemy_row][k-2];
								array[Enemy_row][k-2] = array[Enemy_row][k-1];
								array[Enemy_row][k-1] = temp;

								if (k-2>Player_col && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k-2) == Player_col && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[Enemy_row][k-1] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						///// When enemy's facing a west side and player just wants to pass enemy right side, nothing happen.
						else if (Player_col > Enemy_col)

						{
							aux = array[Player_row-1][Player_col];
							array[Player_row-1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row -= 1;
							*Player_direction = 'n';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);



						}

					}
////////////Enemy direction is East and tank is tryin gto pass that way. it will get shot.
					//When enemy faces East, and player row-1 with enemy row and player tries to pass that row.
					else if ((*Enemy_direction == 'e') && Player_row-1 == Enemy_row && enemy_hp > 0 &&  player_hp > 0)
					{
						//when enemy faces East, and player tries to pass that way ------ YOU LOSE
						if (Player_col > Enemy_col)
						{

							aux = array[Player_row-1][Player_col];
							array[Player_row-1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row -= 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row][Enemy_col+1] = '-';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_col; k<Player_col-1; k++)
							{
								temp = array[Enemy_row][k+2];
								array[Enemy_row][k+2] = array[Enemy_row][k+1];
								array[Enemy_row][k+1] = temp;

								if (k+2<Player_col && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k+2) == Player_col && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[Enemy_row][k+1] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						//When Enemy faces East and player tries to pass West side - nothing happen
						else if (Player_col < Enemy_col)
						{
							aux = array[Player_row-1][Player_col];
							array[Player_row-1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row -= 1;
							*Player_direction = 'n';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);


						}

					}
				}
			}
			//When you choose different direction with current direction, it will just change the direction.from here to
			else if ((choice == 's') && (enemy_hp > 0)){
				array[Player_row][Player_col] = 'v';
				*Player_direction = 's';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'a') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '<';
				*Player_direction = 'w';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'd') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '>';
				*Player_direction = 'e';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			//until here
			//shooting function.
			else if ((choice == 'f') && (enemy_hp > 0)){
				//when player is just under the enemy, and shoot.
				if ((Player_row-1)==Enemy_row && Player_col==Enemy_col && enemy_hp > 0)
				{
					array[Enemy_row][Enemy_col] = 'X';
					enemy_hp -= 1000;
					system("clear");
					fflush(stdin);
				}
				//when player is standing with same columns but differnet row.
				else if ((Player_row-1)!=Enemy_row && Player_col==Enemy_col && enemy_hp > 0){
					//when player is under the enemy, so if player shoot, enemy will get shot and will be changed as 'X'.
					if (Player_row > Enemy_row && enemy_hp > 0)
						{
						array[Player_row-1][Player_col] = '|';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
	
						system("clear");
						fflush(stdin);
						for (i=Player_row; i>1; i--)
						{
							temp = array[i-2][Player_col];
							array[i-2][Player_col] = array[i-1][Player_col];
							array[i-1][Player_col] = temp;
							fflush(stdin);
							if (i-2==0){
								array[i-1][Player_col] = ' ';
								array[i-2][Player_col] = '*';
							}					
							else if ((i-2)>Enemy_row && Player_col==Enemy_col && enemy_hp > 0){	
								for (j=0; j<Rows; j++)
								{
									for(k=0; k<Columns; k++)
									{
										printf("%c", array[j][k]);
									}			
									printf("\n");		
								}
								ucpSleep(0.25);
								system("clear");
								fflush(stdin);
								
							}
							else if((i-1)==Enemy_row && Player_col==Enemy_col && enemy_hp > 0)
							{
								array[Enemy_row][Enemy_col] = 'X';
								array[i][Player_col] = ' ';
								enemy_hp -= 1000;
								fflush(stdin);	
							}				
						}

					}
					//When Player is on the enemy and shoot the wall, it will just hit the wall.
					else if (Player_row < Enemy_row && enemy_hp > 0)
					{
						array[Player_row-1][Player_col] = '|';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
	
						system("clear");
						fflush(stdin);
						for (i=Player_row; i>1; i--)
						{
							temp = array[i-2][Player_col];
							array[i-2][Player_col] = array[i-1][Player_col];
							array[i-1][Player_col] = temp;
	
							if (i-2==0){
								array[i-1][Player_col] = ' ';
								array[i-2][Player_col] = '*';
							}				
	
							for (j=0; j<Rows; j++)
							{
								for(k=0; k<Columns; k++)
								{
									printf("%c", array[j][k]);
								}			
								printf("\n");		
							}
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);
						}			
					}
				}
				//when player are with different columns so the lazer will hit the wall.
				else {
					array[Player_row-1][Player_col] = '|';
					for (j=0; j<Rows; j++)
					{
						for(k=0; k<Columns; k++)
						{
							printf("%c", array[j][k]);
						}			
						printf("\n");		
					}

					system("clear");
					fflush(stdin);
					for (i=Player_row; i>1; i--)
					{
						temp = array[i-2][Player_col];
						array[i-2][Player_col] = array[i-1][Player_col];
						array[i-1][Player_col] = temp;

						if (i-2==0){
							array[i-1][Player_col] = ' ';
							array[i-2][Player_col] = '*';
						}				

						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}			


				}	
				fflush(stdin);
			}
		}




////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///When player direction is South
		else if ((*Player_direction == 's') && (enemy_hp > 0) && (player_hp > 0))
		{
			//When player direction is South and wants to go down
			if (choice == 's' && enemy_hp > 0 && player_hp > 0)
			{
				///When Player is just on the Enemy, and when player wants to move to South, it won't change anything.
				if ((Player_row+1)==Enemy_row && Player_col==Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					printf("can't change\n");
					system("clear");
					fflush(stdin);
				}
				else if ((Player_row+1)!=Enemy_row && Player_col==Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					aux = array[Player_row+1][Player_col];
					array[Player_row+1][Player_col] = array[Player_row][Player_col];
					array[Player_row][Player_col] = aux;
					Player_row += 1;
					*Player_direction = 's';
					ucpSleep(0.25);
					system("clear");
					fflush(stdin);
				}
				else if (Player_row+1 == Rows-1)
				{
					printf("can't move\n");
					system("clear");
					fflush(stdin);
				}
				//When Player and Enemy is on different Column. (Assumption for making a enemy tank shoot the player tank)
				else if(Player_row + 1 < Rows -1  && Player_col != Enemy_col && enemy_hp > 0 && player_hp > 0){
					//When Player moves only South, if enemy direction is North or South, it won't affect anyting. so player will just move to South)
					if (*Enemy_direction == 'n' || *Enemy_direction == 's')
					{
						aux = array[Player_row+1][Player_col];
						array[Player_row+1][Player_col] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_row += 1;
						*Player_direction = 's';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
					//But when enemy faces West or East and player moves but only if player tank is not just on the enemy, it will just move to South.
					else if ((*Enemy_direction == 'w' || *Enemy_direction == 'e') && Player_row+1 != Enemy_row && enemy_hp > 0 && player_hp > 0)
					{
						aux = array[Player_row+1][Player_col];
						array[Player_row+1][Player_col] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_row += 1;
						*Player_direction = 's';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}

					// When enemy faces West and Player+1 row is same with enemy row.
					else if ((*Enemy_direction == 'w') && Player_row+1 == Enemy_row && enemy_hp > 0 &&  player_hp > 0)
					{
						///// When enemy's facing a west side and player passes to enemy west side------YOU LOSE
						if (Player_col < Enemy_col)
						{

							aux = array[Player_row+1][Player_col];
							array[Player_row+1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row += 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row][Enemy_col-1] = '-';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_col; k>Player_col+1; k--)
							{
								temp = array[Enemy_row][k-2];
								array[Enemy_row][k-2] = array[Enemy_row][k-1];
								array[Enemy_row][k-1] = temp;

								if (k-2>Player_col && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k-2) == Player_col && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[Enemy_row][k-1] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						///// When enemy's facing a west side and player just wants to pass enemy right side, nothing happen.
						else if (Player_col > Enemy_col)

						{
							aux = array[Player_row+1][Player_col];
							array[Player_row+1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row += 1;
							*Player_direction = 's';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);



						}

					}
					//When enemy faces East, and player row-1 with enemy row and player tries to pass that row.
					else if ((*Enemy_direction == 'e') && Player_row+1 == Enemy_row && enemy_hp > 0 &&  player_hp > 0)
					{
						//when enemy faces East, and player tries to pass that way ------ YOU LOSE
						if (Player_col > Enemy_col)
						{

							aux = array[Player_row+1][Player_col];
							array[Player_row+1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row += 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row][Enemy_col+1] = '-';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_col; k<Player_col-1; k++)
							{
								temp = array[Enemy_row][k+2];
								array[Enemy_row][k+2] = array[Enemy_row][k+1];
								array[Enemy_row][k+1] = temp;

								if (k+2<Player_col && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k+2) == Player_col && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[Enemy_row][k+1] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						//When Enemy faces East and player tries to pass West side - nothing happen
						else if (Player_col < Enemy_col)
						{
							aux = array[Player_row+1][Player_col];
							array[Player_row+1][Player_col] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_row += 1;
							*Player_direction = 's';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);


						}

					}
				}
			}

//////////////	경계선
			
			else if ((choice == 'w') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '^';
				*Player_direction = 'n';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'a') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '<';
				*Player_direction = 'w';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'd') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '>';
				*Player_direction = 'e';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'f') && (enemy_hp > 0)){
				if ((Player_row+1)==Enemy_row && Player_col==Enemy_col && enemy_hp > 0)
				{
					array[Enemy_row][Enemy_col] = 'X';
					enemy_hp -= 1000;
					system("clear");
					fflush(stdin);
				}
				else if ((Player_row+1)!=Enemy_row && Player_col==Enemy_col && enemy_hp > 0){

					if (Player_row < Enemy_row && enemy_hp > 0)
					{

						array[Player_row+1][Player_col] = '|';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}

						system("clear");
						for (i=Player_row; i<Rows-2; i++)
						{
							temp = array[i+2][Player_col];
							array[i+2][Player_col] = array[i+1][Player_col];
							array[i+1][Player_col] = temp;
		
							if (i+3==Rows){
								array[i+1][Player_col] = ' ';
								array[i+2][Player_col] = '*';
							}					
							else if ((i+2)<Enemy_row && Player_col==Enemy_col && enemy_hp > 0){
								for (j=0; j<Rows; j++)
								{
									for(k=0; k<Columns; k++)
									{
										printf("%c", array[j][k]);
									}			
									printf("\n");		
								}
								ucpSleep(0.25);
								system("clear");
								fflush(stdin);
							}
							else if((i+1)==Enemy_row && Player_col==Enemy_col && enemy_hp > 0)
							{
								array[Enemy_row][Enemy_col] = 'X';
								array[i][Player_col] = ' ';
								enemy_hp -= 1000;
								fflush(stdin);
							}
						}	

					}
					else if (Player_row > Enemy_row && enemy_hp > 0)
					{
						array[Player_row+1][Player_col] = '|';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
	
	
						system("clear");
						for (i=Player_row; i<Rows-2; i++)
						{
							temp = array[i+2][Player_col];
							array[i+2][Player_col] = array[i+1][Player_col];
							array[i+1][Player_col] = temp;
		
							if (i+3==Rows){
								array[i+1][Player_col] = ' ';
								array[i+2][Player_col] = '*';
							}					
		
							for (j=0; j<Rows; j++)
							{
								for(k=0; k<Columns; k++)
								{
									printf("%c", array[j][k]);
								}			
								printf("\n");		
							}
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);
						}		

					}

				}
				else {
					array[Player_row+1][Player_col] = '|';
					for (j=0; j<Rows; j++)
					{
						for(k=0; k<Columns; k++)
						{
							printf("%c", array[j][k]);
						}			
						printf("\n");		
					}


					system("clear");
					for (i=Player_row; i<Rows-2; i++)
					{
						temp = array[i+2][Player_col];
						array[i+2][Player_col] = array[i+1][Player_col];
						array[i+1][Player_col] = temp;
	
						if (i+3==Rows){
							array[i+1][Player_col] = ' ';
							array[i+2][Player_col] = '*';
						}					
	
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}				
				}
				fflush(stdin);
			}
		}

/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

		else if ((*Player_direction == 'w') && (enemy_hp > 0))
		{

//////////////	경계선
			if (choice == 'a' && enemy_hp > 0 && player_hp > 0)
			{
				///When Player is just right side of the Enemy, and when player wants to move to West, it won't change anything.
				if (Player_row==Enemy_row && (Player_col-1)==Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					printf("can't change\n");
					system("clear");
					fflush(stdin);
				}
				else if (Player_row==Enemy_row && (Player_col-1)!=Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					aux = array[Player_row][Player_col-1];
					array[Player_row][Player_col-1] = array[Player_row][Player_col];
					array[Player_row][Player_col] = aux;
					Player_col -= 1;
					*Player_direction = 'w';
					ucpSleep(0.25);
					system("clear");
					fflush(stdin);
				}
				else if (Player_col-1 == 0)
				{
					printf("can't move\n");
					system("clear");
					fflush(stdin);
				}
				//When Player and Enemy is on different Row. (Assumption for making a enemy tank shoot the player tank)
				else if(Player_row != Enemy_row && Player_col-1 > 0 && enemy_hp > 0 && player_hp > 0){
					//When Player moves only West, if enemy direction is West or East, it won't affect anyting. so player will just move to North)
					if (*Enemy_direction == 'w' || *Enemy_direction == 'e')
					{
						aux = array[Player_row][Player_col-1];
						array[Player_row][Player_col-1] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_col -= 1;
						*Player_direction = 'w';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
					//But when enemy faces North or South and player moves but only if player tank is not just right side of the enemy, it will just move to West.
					else if ((*Enemy_direction == 'n' || *Enemy_direction == 's') && Player_col-1 != Enemy_col && enemy_hp > 0 && player_hp > 0)
					{
						aux = array[Player_row][Player_col-1];
						array[Player_row][Player_col-1] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_col -= 1;
						*Player_direction = 'w';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}

					// When enemy faces North and Player_col-1 is same with enemy columns.
					else if ((*Enemy_direction == 'n') && Player_col-1 == Enemy_col && enemy_hp > 0 &&  player_hp > 0)
					{
						///// When enemy's facing a west side and player passes to enemy west side------YOU LOSE
						if (Player_row < Enemy_row)
						{

							aux = array[Player_row][Player_col-1];
							array[Player_row][Player_col-1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col -= 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row-1][Enemy_col] = '|';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_row; k>Player_row+1; k--)
							{
								temp = array[k-2][Enemy_col];
								array[k-2][Enemy_col] = array[k-1][Enemy_col];
								array[k-1][Enemy_col] = temp;

								if (k-2>Player_row && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k-2) == Player_col && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[k-1][Enemy_col] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						///// When enemy's facing a North side and player just wants to pass enemy down side, nothing happen.
						else if (Player_row > Enemy_row)

						{
							aux = array[Player_row][Player_col-1];
							array[Player_row][Player_col-1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col -= 1;
							*Player_direction = 'w';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);



						}

					}
					//When enemy faces South, and player col-1 with enemy col and player tries to pass that row.
					else if ((*Enemy_direction == 's') && Player_col-1 == Enemy_col && enemy_hp > 0 &&  player_hp > 0)
					{
						//when enemy faces South, and player tries to pass that way ------ YOU LOSE
						if (Player_row > Enemy_row)
						{

							aux = array[Player_row][Player_col-1];
							array[Player_row][Player_col-1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col -= 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row+1][Enemy_col] = '|';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_row; k<Player_row-1; k++)
							{
								temp = array[k+2][Enemy_col];
								array[k+2][Enemy_col] = array[k+1][Enemy_col];
								array[k+1][Enemy_col] = temp;

								if (k+2<Player_row && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k+2) == Player_row && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[k+1][Enemy_col] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						//When Enemy faces East and player tries to pass West side - nothing happen
						else if (Player_row < Enemy_row)
						{
							aux = array[Player_row][Player_col-1];
							array[Player_row][Player_col-1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col -= 1;
							*Player_direction = 'w';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);


						}

					}
				}
			}








//////////////경계선
			else if ((choice == 'w') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '^';
				*Player_direction = 'n';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'd') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '>';
				*Player_direction = 'e';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 's') && (enemy_hp > 0)){
				array[Player_row][Player_col] = 'v';
				*Player_direction = 's';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'f') && (enemy_hp > 0)){
				if (Player_row==Enemy_row && (Player_col-1)==Enemy_col && enemy_hp > 0)
				{
					array[Enemy_row][Enemy_col] = 'X';
					enemy_hp -= 1000;
					system("clear");
					fflush(stdin);
				}
				else if (Player_row==Enemy_row && (Player_col-1)!=Enemy_col && enemy_hp > 0){

					if (Player_col > Enemy_col && enemy_hp > 0)
					{
						array[Player_row][Player_col-1] = '-';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						
						system("clear");
						for (i=Player_col; i>1; i--)
						{
							temp = array[Player_row][i-2];
							array[Player_row][i-2] = array[Player_row][i-1];
							array[Player_row][i-1] = temp;	
	
							if (i-2==0){
								array[Player_row][i-1] = ' ';
								array[Player_row][i-2] = '*';
							}					
							else if (Player_row==Enemy_row && (i-2)>Enemy_col && enemy_hp > 0){
	
								for (j=0; j<Rows; j++)
								{
									for(k=0; k<Columns; k++)
									{
										printf("%c", array[j][k]);
									}			
									printf("\n");		
								}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);
							}
							else if (Player_row==Enemy_row && (i-1)==Enemy_col && enemy_hp > 0)
							{	
								array[Enemy_row][Enemy_col] = 'X';
								array[Player_row][i] = ' ';
								enemy_hp -= 1000;
								fflush(stdin);
							}
						}
					}
					else if (Player_col < Enemy_col && enemy_hp > 0)
					{
						array[Player_row][Player_col-1] = '-';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						system("clear");
						for (i=Player_col; i>1; i--)
						{
							temp = array[Player_row][i-2];
							array[Player_row][i-2] = array[Player_row][i-1];
							array[Player_row][i-1] = temp;
		
							if (i-2==0){
								array[Player_row][i-1] = ' ';
								array[Player_row][i-2] = '*';
							}					
		
							for (j=0; j<Rows; j++)
							{
								for(k=0; k<Columns; k++)
								{
									printf("%c", array[j][k]);
								}			
								printf("\n");		
							}
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);
						}
					}
				}
				else {
					array[Player_row][Player_col-1] = '-';
					for (j=0; j<Rows; j++)
					{
						for(k=0; k<Columns; k++)
						{
							printf("%c", array[j][k]);
						}			
						printf("\n");		
					}
					system("clear");
					for (i=Player_col; i>1; i--)
					{
						temp = array[Player_row][i-2];
						array[Player_row][i-2] = array[Player_row][i-1];
						array[Player_row][i-1] = temp;
	
						if (i-2==0){
							array[Player_row][i-1] = ' ';
							array[Player_row][i-2] = '*';
						}					
	
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
				}
				fflush(stdin);
			}		
		}
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
//When player directino is East
		else if ((*Player_direction == 'e') && (enemy_hp > 0) && (player_hp > 0))
		{
////////////When player direction is East and wants to go East way.
			if (choice == 'd' && enemy_hp > 0 && player_hp > 0)
			{
				///When Player is just left side of the Enemy, and when player wants to move to East, it won't change anything.
				if (Player_row==Enemy_row && (Player_col+1)==Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					printf("can't change\n");
					system("clear");
					fflush(stdin);
				}

				else if (Player_row==Enemy_row && (Player_col+1)!=Enemy_col && enemy_hp > 0 && player_hp > 0)
				{
					aux = array[Player_row][Player_col+1];
					array[Player_row][Player_col+1] = array[Player_row][Player_col];
					array[Player_row][Player_col] = aux;
					Player_col += 1;
					*Player_direction = 'e';
					ucpSleep(0.25);
					system("clear");
					fflush(stdin);
				}
				else if (Player_col+1 == Columns-1)
				{
					printf("can't move\n");
					system("clear");
					fflush(stdin);
				}
				//When Player and Enemy is on different Row. (Assumption for making a enemy tank shoot the player tank)
				else if(Player_row != Enemy_row && Player_col+1 < Columns -1 && enemy_hp > 0 && player_hp > 0){
					//When Player moves only East, if enemy direction is West or East, it won't affect anyting. so player will just move to North)
					if (*Enemy_direction == 'w' || *Enemy_direction == 'e')
					{
						aux = array[Player_row][Player_col+1];
						array[Player_row][Player_col+1] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_col += 1;
						*Player_direction = 'e';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
					//But when enemy faces North or South and player moves but only if player tank is not just left side of the enemy, it will just move to West.
					else if ((*Enemy_direction == 'n' || *Enemy_direction == 's') && Player_col+1 != Enemy_col && enemy_hp > 0 && player_hp > 0)
					{
						aux = array[Player_row][Player_col+1];
						array[Player_row][Player_col+1] = array[Player_row][Player_col];
						array[Player_row][Player_col] = aux;
						Player_col += 1;
						*Player_direction = 'e';
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}

					// When enemy faces North and Player_col+1 is same with enemy columns.
					else if ((*Enemy_direction == 'n') && Player_col+1 == Enemy_col && enemy_hp > 0 &&  player_hp > 0)
					{
						///// When enemy's facing a North side and player passes to enemy north side------YOU LOSE
						if (Player_row < Enemy_row)
						{

							aux = array[Player_row][Player_col+1];
							array[Player_row][Player_col+1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col += 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row-1][Enemy_col] = '|';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_row; k>Player_row+1; k--)
							{
								temp = array[k-2][Enemy_col];
								array[k-2][Enemy_col] = array[k-1][Enemy_col];
								array[k-1][Enemy_col] = temp;

								if (k-2>Player_row && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k-2) == Player_col && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[k-1][Enemy_col] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						///// When enemy's facing a North side and player just wants to pass enemy down side, nothing happen.
						else if (Player_row > Enemy_row)

						{
							aux = array[Player_row][Player_col+1];
							array[Player_row][Player_col+1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col += 1;
							*Player_direction = 'e';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);



						}

					}
					//When enemy faces South, and player col+1 with enemy col and player tries to pass that row.
					else if ((*Enemy_direction == 's') && Player_col+1 == Enemy_col && enemy_hp > 0 &&  player_hp > 0)
					{
						//when enemy faces South, and player tries to pass that way ------ YOU LOSE
						if (Player_row > Enemy_row)
						{

							aux = array[Player_row][Player_col+1];
							array[Player_row][Player_col+1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col += 1;
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							array[Enemy_row+1][Enemy_col] = '|';
							for (i=0; i<Rows; i++)
							{
								for(j=0; j<Columns; j++)
								{
									printf("%c", array[i][j]);
								}			
								printf("\n");
							}
							system("clear");
							for(k=Enemy_row; k<Player_row-1; k++)
							{
								temp = array[k+2][Enemy_col];
								array[k+2][Enemy_col] = array[k+1][Enemy_col];
								array[k+1][Enemy_col] = temp;

								if (k+2<Player_row && player_hp > 0 && enemy_hp > 0)
								{
									for (i=0; i<Rows; i++)
									{
										for(j=0; j<Columns; j++)
										{
											printf("%c", array[i][j]);
										}			
										printf("\n");
									}
									ucpSleep(0.25);
									system("clear");
									fflush(stdin);				
								}
								else if ((k+2) == Player_row && player_hp > 0 && enemy_hp > 0)
								{
									array[Player_row][Player_col] = 'X';
									array[k+1][Enemy_col] = ' ';
									player_hp -= 1000;
									fflush(stdin);
									
								}
							}
						}
						//When Enemy faces East and player tries to pass West side - nothing happen
						else if (Player_row < Enemy_row)
						{
							aux = array[Player_row][Player_col+1];
							array[Player_row][Player_col+1] = array[Player_row][Player_col];
							array[Player_row][Player_col] = aux;
							Player_col += 1;
							*Player_direction = 'e';
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);


						}

					}
				}
			}

//////////////	경계선
			else if ((choice == 'w') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '^';
				*Player_direction = 'n';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 'a') && (enemy_hp > 0)){
				array[Player_row][Player_col] = '<';
				*Player_direction = 'w';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if ((choice == 's') && (enemy_hp > 0)){
				array[Player_row][Player_col] = 'v';
				*Player_direction = 's';
				ucpSleep(0.25);
				system("clear");
				fflush(stdin);
			}
			else if (choice == 'f' && (enemy_hp > 0)){
				if (Player_row==Enemy_row && (Player_col+1)==Enemy_col && enemy_hp > 0)
				{
					array[Enemy_row][Enemy_col] = 'X';
					enemy_hp -= 1000;
					system("clear");
					fflush(stdin);
				}
				else if (Player_row==Enemy_row && (Player_col+1)!=Enemy_col && enemy_hp > 0){

					if (Player_col < Enemy_col && enemy_hp > 0)
					{
						array[Player_row][Player_col+1] = '-';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						system("clear");
						for (i=Player_col; i<Columns-2; i++)
						{
							temp = array[Player_row][i+2];
							array[Player_row][i+2] = array[Player_row][i+1];
							array[Player_row][i+1] = temp;
		
							if (i+3==Columns){
								array[Player_row][i+1] = ' ';
								array[Player_row][i+2] = '*';
							}		
	
							else if (Player_row==Enemy_row && (i+2)<Enemy_col && enemy_hp > 0){
								for (j=0; j<Rows; j++)
								{
									for(k=0; k<Columns; k++)
									{
										printf("%c", array[j][k]);
									}			
									printf("\n");		
								}
								ucpSleep(0.25);
								system("clear");
								fflush(stdin);
							}
							else if (Player_row==Enemy_row && (i+1)==Enemy_col && enemy_hp > 0)
							{
								array[Enemy_row][Enemy_col] = 'X';
								array[Player_row][i] = ' ';
								enemy_hp -= 1000;
								fflush(stdin);
							}
						}

					}
					else if (Player_col > Enemy_col && enemy_hp > 0)
					{
						array[Player_row][Player_col+1] = '-';
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						system("clear");
						for (i=Player_col; i<Columns-2; i++)
						{
							temp = array[Player_row][i+2];
							array[Player_row][i+2] = array[Player_row][i+1];
							array[Player_row][i+1] = temp;
		
							if (i+3==Columns){
								array[Player_row][i+1] = ' ';
								array[Player_row][i+2] = '*';
							}					
		
							for (j=0; j<Rows; j++)
							{
								for(k=0; k<Columns; k++)
								{
									printf("%c", array[j][k]);
								}			
								printf("\n");		
							}
							ucpSleep(0.25);
							system("clear");
							fflush(stdin);
						}

					}
////////////////////////
/////////////////////////
				}
				else {
					array[Player_row][Player_col+1] = '-';
					for (j=0; j<Rows; j++)
					{
						for(k=0; k<Columns; k++)
						{
							printf("%c", array[j][k]);
						}			
						printf("\n");		
					}
					system("clear");
					for (i=Player_col; i<Columns-2; i++)
					{
						temp = array[Player_row][i+2];
						array[Player_row][i+2] = array[Player_row][i+1];
						array[Player_row][i+1] = temp;
	
						if (i+3==Columns){
							array[Player_row][i+1] = ' ';
							array[Player_row][i+2] = '*';
						}					
	
						for (j=0; j<Rows; j++)
						{
							for(k=0; k<Columns; k++)
							{
								printf("%c", array[j][k]);
							}			
							printf("\n");		
						}
						ucpSleep(0.25);
						system("clear");
						fflush(stdin);
					}
				}
				fflush(stdin);
			}					
		}



		else
		{
			printf("you put the wrong input\n");
			fflush(stdin);
		}

		system("clear");
		printf("Game's going on111111111111111\n");
		for (i=0; i<Rows; i++)
		{
			for(j=0; j<Columns; j++)
			{
				printf("%c", array[i][j]);
			}			
			printf("\n");
			
		}
		


	}

	if (player_hp < 0)
	{
		printf("you lose");
	}
	else if (enemy_hp < 0)
	{
		printf("You Win!!!");
	}



	for(i=0; i<Rows; i++)
	{
		free(array[i]);
	}
	free(array);
}
