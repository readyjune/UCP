#include <stdio.h>
#include "arrays.h"
#include <stdlib.h>
#include "laser.h"
#include "ucpSleep.h"

int main( int argc, char* argv[])
{

	//if there is not a command line argument.
	if(argc < 2)
	{
		return printf("Error: Must provide proper command line argument!\n");	
	}


	//if player is located outside of the map.
	else if (atoi(argv[3]) < 0 || atoi(argv[3]) > atoi(argv[1]) || atoi(argv[4]) < 0 || atoi(argv[4]) > atoi(argv[2]))
	{
		return printf("Error: player shouldn't be exist outside of map!\n");
	}


	//if enemy is located outside of the map.
	else if (atoi(argv[6]) < 0 || atoi(argv[6]) > atoi(argv[1]) || atoi(argv[7]) < 0 || atoi(argv[7]) > atoi(argv[2]))
	{
		return printf("Error: enemy shouldn't be exist outside of the map!\n");
	}


	//when player and enemy are in same location.
	else if ((argv[3] == argv[6]) && (argv[4] == argv[7]))
	{
		return printf("Error: player and enemy can't be in same location!\n");
	}


	//when player is on the * boundary.
	else if(atoi(argv[3]) == 0 || atoi(argv[4]) == 0 || atoi(argv[3]) == atoi(argv[1]) || atoi(argv[4]) == atoi(argv[2]))
	{
		return printf("Error: Player shouldn't be on the boundary \n");
	}


	//when enemy is on the * boundary.
	else if(atoi(argv[6]) == 0 || atoi(argv[7]) == 0 || atoi(argv[6]) == atoi(argv[1]) || atoi(argv[7]) == atoi(argv[2]))
	{
		return printf("Error: Enemy shouldn't be on the boundary\n");
	}


	// The player tank will not be in front of the enemy tank immediately upon starting the game.(No instant lose)
	// When the enemy tank direction is North or South, player tank shouldn't be in same Columns.
	else if ((*argv[8] == 'n') || (*argv[8] == 's'))
	{
		if (atoi(argv[4]) == atoi(argv[7]))
		{
			return printf("player is dead as soon as you started game\n");
		}
	}


	// When the enemy tank direction is West or East, player tank shouldn't be in the same Rows.
	else if ((*argv[8] == 'w') || (*argv[8] == 'e'))
	{
		if (atoi(argv[3]) == atoi(argv[6]))
		{
			return printf("player is dead as soon as you started game\n");
		}
	}


	// When they don't put proper letter like t, x, q...
	else if ((*argv[5] != 'n') || (*argv[5] != 's') || (*argv[5] != 'w') || (*argv[5] != 'e'))
	{
		if ((*argv[5] == 'N') || (*argv[5] == 'S') || (*argv[5] == 'W') || (*argv[5] == 'E'))
		{
			return printf("Error: you have to put lowercase for letters");
		}
		else if ((*argv[5] != 'N') || (*argv[5] != 'S') || (*argv[5] != 'W') || (*argv[5] != 'E'))
		{
			return printf("Error: please put valid letter!");
		}

	}

	// When they didn't put proper letter like t, x q...
	else if ((*argv[8] != 'n') || (*argv[8] != 's') || (*argv[8] != 'w') || (*argv[8] != 'e'))
	{
		if ((*argv[8] == 'N') || (*argv[8] == 'S') || (*argv[8] == 'W') || (*argv[8] == 'E'))
		{
			return printf("Error: you have to put lowercase for letters");
		}
		else if ((*argv[8] != 'N') || (*argv[8] != 'S') || (*argv[8] != 'W') || (*argv[8] != 'E'))
		{
			return printf("Error: please put valid letter!");
		}

	}




	map(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), argv[5], atoi(argv[6]), atoi(argv[7]), argv[8]);





	return 0;
}









