void laservim(int Rows, int Columns, int Player_row, int Player_col, char* Player_direction, int Enemy_row, int Enemy_col, char* Enemy_direction)
//{
//	if (*Player_direction = 's')
//	{
//		for(i=Player_row; i<Rows-1; i++)
//		{
//			for(j=0; j<Columns; j++)
//			{
//				printf("%c", array[i][j];)
//			}
//			printf("\n");
//		} 
//	}
//
//}

//////////////


//{
//	if (*Player_direction = 's')
//	{
//		for (i=0; i<Rows; i++)
//		{		
//			for(j=0; j<Columns; j++)
//			{
//				printf("%c", array[i][j]);
//			}
//				printf("\n");
//		}
//	}
//}
