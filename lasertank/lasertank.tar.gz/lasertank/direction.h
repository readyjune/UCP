void character_direction(char** array, int Player_row, int Player_col, char* Player_direction, int Enemy_col, int Enemy_row, char* Enemy_direction);

